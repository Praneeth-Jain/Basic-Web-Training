using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace LoginPage.Pages
{
    public class ResponseModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
