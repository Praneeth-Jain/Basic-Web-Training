using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.ComponentModel.DataAnnotations;
using LoginPage.Pages.Shared.RegisterModelClass;
using Microsoft.AspNetCore.Mvc.Rendering;
using LoginPage.Data.Context;
using LoginPage.Data.Entity;

namespace LoginPage.Pages
{
    public class RegisterModel : PageModel
    {

        private readonly AppDbContext _context;

        public RegisterModel(AppDbContext context)
        {
            _context = context;
        }



        [BindProperty]
        public RegisterModelClass RegistredUser { get; set; }

        public void PopulateOptions()
        {
            if (RegistredUser == null)
            {
                RegistredUser = new RegisterModelClass();
            }

            RegistredUser.Gender = new List<SelectListItem> {
             new SelectListItem {Value="M",Text="Male"},
             new SelectListItem {Value="F",Text="Female"},
             new SelectListItem {Value="O",Text="Others"},
            };
        }
        public IActionResult OnPost()
        {
            if (!ModelState.IsValid)
            {
                return Page(); 
            }
            var newCus = new Customer
            {
                Name = RegistredUser.Username,
                Email = RegistredUser.Email,
                Password = RegistredUser.Password,
                Age = RegistredUser.Age
            }; 
            _context.customers.Add(newCus);
            _context.SaveChanges();
            TempData["Message"] = "Account Created Successfully";
            TempData["link"] = "/Signup";
            return RedirectToPage("Response");
        }

        public void OnGet()
        {
            PopulateOptions();
        }

    }
}


