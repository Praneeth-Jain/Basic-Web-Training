using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace LoginPage.Pages
{
    public class AdminHomeModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
