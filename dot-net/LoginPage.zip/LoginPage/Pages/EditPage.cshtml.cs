using LoginPage.Data.Context;
using LoginPage.Data.Entity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace LoginPage.Pages
{
    public class EditPageModel : PageModel
    {
        private readonly AppDbContext _context;

        [BindProperty]
        public Customer MyCustomer { get; set; }
        
        public EditPageModel(AppDbContext context)
        {
            _context = context;
        }
        public void OnGet()
        {
        }public void OnGetEditHandler(int? id)
        {
            Console.WriteLine(id);
            var editUser = _context.customers.Find(id);
            MyCustomer = editUser;
        }
        public IActionResult OnPostSave()
        {
            var SaveUser=_context.customers.Find(MyCustomer.Id);
            if(SaveUser != null)
            {
                SaveUser.Name = MyCustomer.Name;
                SaveUser.Email = MyCustomer.Email;
                SaveUser.Password = MyCustomer.Password;
                SaveUser.Age = MyCustomer.Age;
                _context.SaveChanges();
            }
            return RedirectToPage("/AdminHome");  
        }
        
    }
}
