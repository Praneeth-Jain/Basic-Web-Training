using LoginPage.Data.Context;
using LoginPage.Data.Entity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace LoginPage.Pages.Product
{
    public class AddProductsModel : PageModel
    {
        private readonly AppDbContext _context;

        [BindProperty]
        public ProductModelcs product { get; set; }

        public AddProductsModel(AppDbContext context) 
        {
            _context = context;
        }

        public void OnGet()
        {

        }

        public IActionResult OnPostAddProduct()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }
            var newProd = new Products { 
                ProductName=product.ProductName,
                ProductDescription=product.ProductDescription,
                ProductCategoryName=product.ProductCategory,
                ProductPrice=product.ProductPrice,
                Quantity=product.quantity
            };
            _context.products.Add(newProd);
            _context.SaveChanges();
            TempData["ProductsMsg"] = "Product Added Successfully";
            return RedirectToPage("/Product/Index");   
        }
    }
}
